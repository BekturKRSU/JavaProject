package space.kanybekov.textscore;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import java.time.OffsetTime;
import org.w3c.dom.Text;

import java.util.Date;

public class GameLevel extends AppCompatActivity implements View.OnClickListener {
    TextView FirstText;
    TextView Timers;
    EditText SecondText;
    long start;
    long finish;

    Button btnSubmit;
    @Override
    public void onBackPressed() {
        Toast.makeText(this, "Во время боя переход назад не возможен", Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_level);
        Window w = getWindow();
        w.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        start = System.currentTimeMillis();
        FirstText = (TextView) findViewById(R.id.firstText);

        FirstText.setText("Do you like learning English?");

        SecondText = (EditText) findViewById(R.id.secondText);

        btnSubmit = (Button) findViewById(R.id.finishButton);
        btnSubmit.setOnClickListener(this);
    }

    @Override
    public void onClick(View v){

        finish = (System.currentTimeMillis() - start)/1000;

        Intent intent = new Intent(this, GameResult.class);

        intent.putExtra("firstText", FirstText.getText().toString());
        intent.putExtra("secondText", SecondText.getText().toString());
        intent.putExtra("Timers", Long.toString(finish));
        startActivity(intent);

    }
}
