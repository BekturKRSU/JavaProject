package space.kanybekov.textscore;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;

public class GameResult extends AppCompatActivity implements View.OnClickListener {

    TextView Result;

    @Override
    public void onBackPressed() {
        Toast.makeText(this, "Во время боя переход назад не возможен", Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_result);
        Window w = getWindow();
        w.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        Result = (TextView) findViewById(R.id.Result);

        Intent intent = getIntent();


        String FirstText = intent.getStringExtra("firstText");
        String SecondText = intent.getStringExtra("secondText");

        int count = chekString(FirstText, SecondText);
        String timers = intent.getStringExtra("Timers");
        Result.setText("Первый текст: " + FirstText + "\nВторой текст: " + SecondText + "\nВаша скорость набора: " + timers + " сек" + "\nКоличество ошибок: " + count);
    }

    @Override
    public void onClick(View v){
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

    public int chekString(String first, String second){
        int count = 0;
        count = Math.abs( first.length() - second.length());
        int minLength = Math.min(first.length(),second.length());
        for (int i = 0; i < minLength; i++)
        {
            if(first.charAt(i) != second.charAt(i))
                count++;
        }
        return count;
    }
}
